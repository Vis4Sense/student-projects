# my_project/ui_streamlit/app.py
import streamlit as st
import requests
import pandas as pd

API = "http://localhost:3000"

st.set_page_config(page_title="Zotero Chat Assistant (Prototype)", layout="centered")
st.title("Zotero Chat Assistant — Prototype")

# --- 搜索区 ---
with st.form(key="search_form", clear_on_submit=False):
    query = st.text_input("Ask your library (自然语言查询)", placeholder="e.g., transformer in medical imaging")
    topk = st.number_input("Top K", min_value=1, max_value=20, value=5, step=1)
    submitted = st.form_submit_button("🔎 Search")
    if submitted and query.strip():
        try:
            r = requests.post(f"{API}/semantic_search", json={"query": query, "top_k": int(topk)}, timeout=60)
            r.raise_for_status()
            st.session_state["results"] = r.json().get("results", [])
        except Exception as e:
            st.error(f"Search failed: {e}")

results = st.session_state.get("results", [])

if results:
    st.subheader("Search Results")
    st.dataframe(pd.DataFrame(results), use_container_width=True, hide_index=True)

    ids = [item["id"] for item in results]
    # --- 引用对比（选两篇） ---
    with st.expander("Compare Citations (选两篇)"):
        col1, col2, col3 = st.columns([1,1,0.5])
        with col1:
            a_id = st.selectbox("Paper A", ids, key="cmp_a")
        with col2:
            b_id = st.selectbox("Paper B", ids, key="cmp_b")
        with col3:
            if st.button("Compare", use_container_width=True):
                try:
                    r = requests.post(f"{API}/citation_relation", json={"a_id": a_id, "b_id": b_id}, timeout=60)
                    r.raise_for_status()
                    data = r.json()
                    nodes = {n["id"]: n.get("label", n["id"]) for n in data.get("nodes", [])}
                    edges = data.get("edges", [])

                    # 用 Graphviz 画一个小网络（无需安装额外库）
                    dot = ["digraph G {", 'rankdir=LR; node [shape=ellipse, fontsize=10];']
                    for nid, label in nodes.items():
                        safe_label = label.replace('"', "'")
                        dot.append(f'"{nid}" [label="{safe_label}"];')
                    for e in edges:
                        dot.append(f'"{e["src"]}" -> "{e["dst"]}";')
                    dot.append("}")
                    st.graphviz_chart("\n".join(dot))
                    with st.expander("Raw JSON"):
                        st.json(data)
                except Exception as e:
                    st.error(f"Compare failed: {e}")

    # --- 聚类与可视化（多选） ---
    with st.expander("Clustering & Visualization (多选若干篇)"):
        sel = st.multiselect("Pick papers", ids, default=ids[:min(5, len(ids))])
        if st.button("Cluster", use_container_width=True, key="btn_cluster"):
            if len(sel) < 2:
                st.warning("请至少选择 2 篇论文进行聚类。")
            else:
                try:
                    r = requests.post(f"{API}/cluster_papers", json={"ids": sel}, timeout=60)
                    r.raise_for_status()
                    layout = r.json().get("layout", [])
                    if not layout:
                        st.info("无聚类结果。")
                    else:
                        # 用 Vega-Lite（Streamlit 内置）画散点，不需要额外安装包
                        spec = {
                            "mark": {"type": "circle", "tooltip": True},
                            "encoding": {
                                "x": {"field": "x", "type": "quantitative"},
                                "y": {"field": "y", "type": "quantitative"},
                                "color": {"field": "cluster", "type": "nominal"},
                                "tooltip": [{"field": "title", "type": "nominal"}],
                            },
                            "data": {"values": layout},
                        }
                        st.vega_lite_chart(spec, use_container_width=True)
                        with st.expander("Raw JSON"):
                            st.json(layout)
                except Exception as e:
                    st.error(f"Cluster failed: {e}")
else:
    st.info("先在上面输入查询并点击 Search。")

st.caption("Prototype UI — connects to /semantic_search, /citation_relation, /cluster_papers on localhost:3000")
