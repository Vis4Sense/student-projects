// Robust import Services (ESM first, then JSM)
var Zotero = globalThis.Zotero;
var ChromeUtils = globalThis.ChromeUtils;
var Services;
try { ({ Services } = ChromeUtils.importESModule("resource://gre/modules/Services.sys.mjs")); }
catch (e1) {
  try { ({ Services } = ChromeUtils.import("resource://gre/modules/Services.jsm")); }
  catch (e2) { dump("[ZCA] Services import failed\n"); Services = null; }
}

const XUL_NS  = "http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul";
const MENU_ID = "menu-zca-open";

function log(m){
  try { Zotero?.debug?.("[ZCA] " + m); } catch(_) {}
  try { console.log("[ZCA] " + m); } catch(_) {}
}

// 注入「工具 → Chat Assistant」
function injectMenu(win, attempt=1){
  try{
    if(!win || !win.document){ log("no window/document"); return false; }
    const doc   = win.document;
    const tools = doc.getElementById("menu_ToolsPopup") || doc.querySelector("#menu_ToolsPopup");
    if(!tools){
      if(attempt <= 5){ log("Tools menu not found, retry " + attempt); win.setTimeout(()=>injectMenu(win,attempt+1), 400); }
      else{ log("Tools menu not found after retries"); }
      return false;
    }
    const old = doc.getElementById(MENU_ID); if(old){ try{ old.remove(); }catch(_){} }

    const mi = doc.createElementNS(XUL_NS, "menuitem");
    mi.setAttribute("id", MENU_ID);
    mi.setAttribute("label", "Chat Assistant");
    mi.addEventListener("command", ()=>{
      log("menu clicked");
      try { Services.prompt.alert(win, "ZCA", "Opening /ui"); } catch(_) {}
      Zotero.launchURL("http://127.0.0.1:3031/ui");
    });
    tools.appendChild(mi);
    log("menu injected");
    return true;
  }catch(e){ log("injectMenu error: " + e); return false; }
}

// 生命周期
const windowListener = {
  onOpenWindow(xulWin){
    try{ const w = xulWin.docShell.domWindow; w.addEventListener("load", ()=>injectMenu(w,1), {once:true}); }
    catch(e){ log("onOpenWindow error: " + e); }
  }, onCloseWindow(){}, onWindowTitleChange(){}
};

function install() {}
function uninstall() {}
function startup({version}){
  try{
    log("startup v" + version);
    if (!Services) { dump("[ZCA] abort startup: Services unavailable\n"); return; }
    let main = (Zotero && Zotero.getMainWindow && Zotero.getMainWindow()) || Services.wm.getMostRecentWindow(null);
    if(main){
      try{ Services.prompt.alert(main, "ZCA", "ZCA started v" + version); }catch(_) {}
      if(!injectMenu(main,1)){ main.setTimeout(()=>injectMenu(main,2), 600); }
    }
    Services.wm.addListener(windowListener);
    const en = Services.wm.getEnumerator(null);
    while(en.hasMoreElements()) injectMenu(en.getNext(),1);
  }catch(e){ log("startup error: " + e); }
}
function shutdown(){
  try{
    if (Services) Services.wm.removeListener(windowListener);
    const main = Zotero && Zotero.getMainWindow && Zotero.getMainWindow();
    if(main){
      const n = main.document.getElementById(MENU_ID);
      if(n && n.parentNode) n.parentNode.removeChild(n);
    }
    log("shutdown done");
  }catch(e){ log("shutdown error: " + e); }
}
