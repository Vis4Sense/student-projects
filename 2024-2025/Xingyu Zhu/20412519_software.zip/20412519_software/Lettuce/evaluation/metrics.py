from enum import Enum
from typing import Any, List

from sentence_transformers import SentenceTransformer
from sqlalchemy.orm import Session
from evaluation.evaltypes import SingleResultMetric, InformationRetrievalMetric
from rapidfuzz import fuzz
import numpy as np

from omop.omop_queries import query_ancestors_by_name, query_related_by_name


# ------ Single Result Metrics ------
class ExactMatch(SingleResultMetric):
    """
    A metric checking whether the predicted and desired output match.
    This doesn't care what the inputs are.
    """

    def __init__(self) -> None:
        self._description = (
            "Exact match: is the predicted response the same as the ground truth"
        )

    def calculate(self, predicted, actual):
        """
        Calculate the exact match metric.

        Parameters
        ----------
        predicted
            The predicted output from the pipeline.
        actual
            The desired output.

        Returns
        -------
        1 if the predicted and actual outputs match exactly, 0 otherwise.
        """
        return int(predicted == actual)

    @property
    def description(self):
        return self._description


class UncasedMatch(SingleResultMetric):
    """
    A metric for testing whether the predicted and desired outputs are matching strings.
    Case-insensitive and strips whitespace.
    """

    def __init__(self) -> None:
        self._description = "Uncased match: is the predicted response the same as the ground truth, ignoring character case"

    def calculate(self, predicted: str, actual: str) -> float:
        """
        Calculate the exact match metric, if the input value has been wrapped in a list

        Parameters
        ----------
        predicted
            The predicted output from the pipeline
        actual: list
            A list where an item is the desired output of the pipeline
        Returns
        -------
        1 if the predicted and actual outputs match exactly, 0 otherwise
        """
        # We have to do this because the input has to be wrapped in a list for compatibility with prompt templates
        return float(predicted.lower().strip() == actual.lower().strip())

    @property
    def description(self) -> str:
        return self._description


class FuzzyMatchRatio(SingleResultMetric):
    """
    A metric that compares predicted strings to desired output.

    Scores are normalised InDel distance
    """

    def __init__(self) -> None:
        self._description = "Fuzzy Match: the normalized indel similarity between predicted and expected output"

    def calculate(self, predicted: str, actual: str) -> float:
        """
        Calculates the Fuzzy Match Ratio metric

        Parameters
        ----------
        predicted: str
            String output from a SingleResultPipeline
        actual: str
            Ground truth, the string the pipeline is trying to predict
        """
        return fuzz.ratio(predicted.lower(), actual.lower())

    @property
    def description(self):
        return self._description


class DotVectorSimilarityMetric(SingleResultMetric):
    """
    A metric that calculates a vector similarity metric between input and a desired output
    """

    def __init__(
        self,
        embedding_model: SentenceTransformer,
    ):
        self.model = embedding_model
        self._description = (
            "Dot product: the dot product of the vector for input and desired output"
        )

    def calculate(self, embedded_input: np.ndarray, actual: str) -> float:
        embedded_input = embedded_input
        embedded_actual = self.model.encode(actual)

        return float(np.inner(embedded_input, embedded_actual))

    @property
    def description(self) -> str:
        return self._description


class CosineVectorSimilarityMetric(SingleResultMetric):
    """
    A metric that calculates a vector similarity metric between input and a desired output
    """

    def __init__(
        self,
        embedding_model: SentenceTransformer,
    ):
        self.model = embedding_model
        self._description = "Cosine similarity: the cosine similarity between input and output embeddings"

    def calculate(self, embedded_input: np.ndarray, actual: str) -> float:
        embedded_input = embedded_input
        embedded_actual = self.model.encode(actual)

        return float(
            np.inner(embedded_input, embedded_actual)
            / (np.linalg.norm(embedded_input) * np.linalg.norm(embedded_actual))
        )

    @property
    def description(self) -> str:
        return self._description


class RelatedNameUncasedMatch(SingleResultMetric):
    """
    A metric that checks whether the output of a pipeline is a related concept to the target concept
    """

    def __init__(
        self,
        connection: Session,
        vocabulary_ids: list[str] | None = None,
    ) -> None:
        self._description = "Related name: Is the output of a pipeline a related concept to the target concept?"
        self._connection = connection
        self._vocabulary_ids = vocabulary_ids

    def calculate(self, predicted, actual) -> float:
        predicted = predicted.lower().strip()
        # If the correct concept is returned, I think a concept should relate to itself
        if predicted == actual.lower().strip():
            return 1.0
        query = query_related_by_name(
            actual,
            self._vocabulary_ids,
        )
        related_concepts = self._connection.execute(query).fetchall()
        related_names = set(
            result[0].concept_name.lower() for result in related_concepts
        )
        print(related_names)
        print(predicted)
        print(float(predicted in related_names))

        return float(predicted in related_names)

    @property
    def description(self) -> str:
        return super().description


class AncestorNameUncasedMatch(SingleResultMetric):
    def __init__(
        self,
        connection: Session,
        vocabulary_ids: list[str] | None = None,
        min_separation_bound: int = 0,
        max_separation_bound: int | None = None,
    ) -> None:
        """
        Initialises the Ancestor Name uncased match metric

        Parameters
        ----------
        connection: Session
            A connection to an OMOP-CDM database
        vocabulary_ids: list[str]
            A list of vocabularies to use for finding an initial concept
        min_separation_bound: int
            A lower bound for minimum level of separation
        max_separation_bound: int|None
            An upper bound for maximum level of separation
        """
        self._description = "Ancestor concept name precision: Calculates precision, where the set of relevant instances is the concept's ancestors"
        self._min_separation_bound = min_separation_bound
        self._max_separation_bound = max_separation_bound
        self._connection = connection
        self._vocabulary_ids = vocabulary_ids

    def calculate(self, predicted: str, actual: str) -> float:
        # If the correct concept is returned, I think a concept should relate to itself
        if predicted.lower() == actual.lower():
            return 1.0
        query = query_ancestors_by_name(
            actual,
            self._vocabulary_ids,
            min_separation_bound=self._min_separation_bound,
            max_separation_bound=self._max_separation_bound,
        )
        ancestor_concepts = self._connection.execute(query).fetchall()
        ancestor_names = set(
            result[0].concept_name.lower() for result in ancestor_concepts
        )

        return float(predicted in ancestor_names)

    @property
    def description(self) -> str:
        return self._description


# -------- Information Retrieval Metrics --------
def calc_precision(relevant_instances: List[Any], prediction: List[Any]) -> float:
    """
    Compares two lists and calculates precision

    Precision = (Number of relevant instances retrieved)/(Number of instances retrieved)

    Parameters
    ----------
    relevant_instances: List[Any]
        The set of relevant instances, or positive class
    prediction: List[Any]
        A prediction made by an information retrieval system

    Returns
    -------
    float
        A score for the precision
    """
    relevant_retrieved_instances = [x for x in prediction if x in relevant_instances]
    return len(relevant_retrieved_instances) / len(prediction)


def calc_recall(relevant_instances: List[Any], prediction: List[Any]) -> float:
    """
    Compares two lists and calculates recall

    Recall = (Number of relevant instances retrieved)/(Number of relevant instances)

    Parameters
    ----------
    relevant_instances: List[Any]
        The set of relevant instances, or positive class
    prediction: List[Any]
        A prediction made by an information retrieval system

    Returns
    -------
    float
        A score for the recall
    """
    relevant_retrieved_instances = [x for x in prediction if x in relevant_instances]
    return len(relevant_retrieved_instances) / len(relevant_instances)


class PrecisionMetric(InformationRetrievalMetric):
    def __init__(self) -> None:
        self._description = "Precision: a type agnostic precision metric"

    def calculate(self, predicted: List[Any], actual: List[Any]) -> float:
        """
        Calculates precision for the information retrieval pipeline's prediction against a positive set

        Parameters
        ----------
        predicted: List[Any]
            The output of an information retrieval pipeline
        actual: List[Any]
            The set of relevant instances for the input
        """
        return calc_precision(actual, predicted)

    @property
    def description(self) -> str:
        return self._description


class RecallMetric(InformationRetrievalMetric):
    def __init__(self) -> None:
        self._description = "Recall: a type agnostic recall metric"

    def calculate(self, predicted: List[Any], actual: List[Any]) -> float:
        """
        Calculates recall for the information retrieval pipeline's prediction against a positive set

        Parameters
        ----------
        predicted: List[Any]
            The output of an information retrieval pipeline
        actual: List[Any]
            The set of relevant instances for the input
        """
        return calc_recall(actual, predicted)

    @property
    def description(self) -> str:
        return self._description


class FScoreMetric(InformationRetrievalMetric):
    def __init__(self, beta: float) -> None:
        """
        Initialises the F-Score metric

        Parameters
        ----------
        beta: float
            The ratio by which to weight precision to recall
        """
        self._description = (
            "F Score: a type agnostic F-score metric with a Beta of " + str(beta)
        )
        self._beta = beta

    def calculate(self, predicted: List[Any], actual: List[Any]) -> float:
        """
        Calculates F score with the class beta for the information retrieval pipeline's prediction against a positive set

        Parameters
        ----------
        predicted: List[Any]
            The output of an information retrieval pipeline
        actual: List[Any]
            The set of relevant instances for the input
        """
        precision = calc_precision(actual, predicted)
        recall = calc_recall(actual, predicted)
        return (
            (1 + self._beta**2)
            * (precision * recall)
            / ((self._beta**2 * precision) + recall)
        )

    @property
    def description(self) -> str:
        return self._description


class AncestorNamePrecision(InformationRetrievalMetric):
    def __init__(
        self,
        connection: Session,
        vocabulary_ids: list[str],
        min_separation_bound: int = 0,
        max_separation_bound: int | None = None,
    ) -> None:
        """
        Initialises the Ancestor Precision metric

        Parameters
        ----------
        connection: Session
            A connection to an OMOP-CDM database
        vocabulary_ids: list[str]
            A list of vocabularies to use for finding an initial concept
        min_separation_bound: int
            A lower bound for minimum level of separation
        max_separation_bound: int|None
            An upper bound for maximum level of separation
        """
        self._description = "Ancestor concept name precision: Calculates precision, where the set of relevant instances is the concept's ancestors"
        self._min_separation_bound = min_separation_bound
        self._max_separation_bound = max_separation_bound
        self._connection = connection
        self._vocabulary_ids = vocabulary_ids

    def calculate(self, predicted: list[str], actual: str) -> float:
        query = query_ancestors_by_name(
            actual,
            self._vocabulary_ids,
            min_separation_bound=self._min_separation_bound,
            max_separation_bound=self._max_separation_bound,
        )
        ancestor_concepts = self._connection.execute(query).fetchall()
        ancestor_names = set(result[0].concept_name for result in ancestor_concepts)

        return calc_precision(list(ancestor_names), predicted)

    @property
    def description(self) -> str:
        return self._description


class RelatedNamePrecision(InformationRetrievalMetric):
    def __init__(
        self,
        connection: Session,
        vocabulary_ids: list[str],
    ) -> None:
        """
        Initialises the Related concept name precision metric

        Parameters
        ----------
        connection: Session
            A connection to an OMOP-CDM database
        vocabulary_ids: list[str]
            A list of vocabularies to use for finding an initial concept
        min_separation_bound: int
            A lower bound for minimum level of separation
        max_separation_bound: int|None
            An upper bound for maximum level of separation
        """
        self._description = "Related concept name precision: Calculates precision, where the set of relevant instances is the concept's ancestors"
        self._connection = connection
        self._vocabulary_ids = vocabulary_ids

    def calculate(self, predicted: list[str], actual: str) -> float:
        query = query_related_by_name(
            actual,
            self._vocabulary_ids,
        )
        related_concepts = self._connection.execute(query).fetchall()
        related_names = set(result[0].concept_name for result in related_concepts)

        return calc_precision(list(related_names), predicted)

    @property
    def description(self) -> str:
        return self._description
