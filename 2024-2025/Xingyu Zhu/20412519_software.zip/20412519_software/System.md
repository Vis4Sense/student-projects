# README – Medical Data Mapping System

## Front-end and Back-end
The main application file is `app3.py`, which contains both the front-end and back-end logic.

Although the system is implemented within a single Python script, the front-end and back-end components are clearly separated in terms of functionality. The back-end is responsible for data processing, LLM interactions, and internal logic, while the front-end handles user interaction through the Gradio interface. Owing to the unique design of the Gradio library, the separation is further reinforced at the code level: the `with gr.Blocks` line effectively marks the beginning of the front-end section, with the code above it primarily functioning as the back-end.

You can run the system directly by using the command: `python app3.py`

## The AI Component
### Lettuce Server (From Dr James Mitchell-White)

Lettuce Server is in the `Lettuce` folder. Lettuce has been updated during the project development, and the version in this folder is the one used in the project, which has been slightly adjusted. 

For detailed deployment steps and configuration guidance, please refer to the official Lettuce documentation available [here](https://health-informatics-uon.github.io/lettuce/quickstart)

If you would like to build the OMOP-CDM database locally, please refer to the instructions provided [here](https://github.com/Health-Informatics-UoN/omop-lite), 

Then you can run Lettuce using the following command: `poetry run python app.py`



### General LLM Server
The General LLM Server, can be obtained from [Ollama](https://ollama.com/).

### Graph Serve (From Dr James Mitchell-White)
The Graph Server for the AI component is not included in this folder. As this part has not been updated during the development, you can directly obtain it from [here](https://github.com/Health-Informatics-UoN/omop-relationship-graph).











