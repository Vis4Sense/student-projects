import gradio as gr
import pandas as pd
import os
import json
import requests
import random
from pydantic import BaseModel  
from typing import Optional, List
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from langchain.prompts import PromptTemplate
from langchain.llms.base import LLM
from langchain.chains import LLMChain

from pyvis.network import Network
import webbrowser

# Back-end
# Information after mapping
extracted_info_storage = {}  # Key: search_term, Value: extracted_info
stored_search_terms = set()  
data_extract = None  # Used to store temporary tables

# Variable control visible of sidebar
sidebar_visible = False

# The record user select for detail information
selected_record = None  

# The place to store mapping result
mapping_result = pd.DataFrame(columns=[
    "Informal Name", "Reply", "Concept Name", "Concept ID",
    "Domain", "Class", "Concept Code", "Vocabulary ID", "Similarity Score"
])

# The tree to do the record
current_action_tree = None
current_node = None

# The name of output file
outputFile_name = None
outputActionFile_name = None

def extract_important_info(parsed_data):
    extracted_data = {
        'reply': '',
        'informal_name': '',
        'search_term': '',
        'CONCEPT': []
    }
    
    flattened_data = []
    for item in parsed_data:
        if isinstance(item, list):
            flattened_data.extend(item)  
        else:
            flattened_data.append(item)
    
    for item in flattened_data:
        if not isinstance(item, dict):
            continue
        
        event = item.get('event', '')
        data = item.get('data', {})
        
        if event == 'llm_output':
            extracted_data['reply'] = data.get('reply', '')
            extracted_data['informal_name'] = data.get('informal_name', '')
        
        elif event == 'omop_output':
            extracted_data['search_term'] = data.get('search_term', '')
            for concept in data.get('CONCEPT', []):
                extracted_data['CONCEPT'].append({
                    'Concept Name': concept.get('concept_name', ''),
                    'Concept ID': concept.get('concept_id', ''),
                    'Domain': concept.get('domain_id', ''),
                    'Class': concept.get('concept_class_id', ''),
                    'Concept Code': concept.get('concept_code', ''),
                    'Vocabulary ID': concept.get('vocabulary_id', ''),              
                    'Similarity Score': concept.get('concept_name_similarity_score', '')                 
                })
    
    return extracted_data

# Term Search
def query_pipeline(names, url = "http://127.0.0.1:8000/pipeline/"):
    headers = {"Content-Type": "application/json"}
    data = {"names": names}

    response = requests.post(url, json=data, headers=headers)

    if response.status_code != 200:
        print(f"Error: HTTP {response.status_code}")
        return None

    lines = response.text.strip().split("\n")
    parsed_data = []

    for line in lines:
        if line.startswith("data: "):  
            json_part = line[6:].strip()  
            try:
                parsed_data.append(json.loads(json_part))  
            except json.JSONDecodeError as e:
                print(f"JSON fail: {e}")

    return extract_important_info(parsed_data)

# Use ollama to talk with llama
class OllamaLLM(LLM, BaseModel):
    @property
    def _llm_type(self) -> str:
        return "ollama"
    
    def _call(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        return self.invoke(prompt)

    def invoke(self, prompt: str, stop: Optional[List[str]] = None) -> str:
        response = get_completion(prompt=prompt)
        if response is None:
            raise ValueError("Failed to get a valid response from LLaMA server.")
        return response

llm = OllamaLLM(model_name="llama32")

# The template or prompt
prompt = PromptTemplate(
    input_variables=["input"],
    template=(
        "{input}"
        )
    )


# Select cell (for detail information)
def select_cell(evt: gr.SelectData):
    return evt.value  

def wrap_as_list(value):
    return [value] if isinstance(value, str) else value

# Generate temporary table
def generate_temp_excel():
    global data_extract

    # No data
    if not extracted_info_storage:
        return None 

    #print(extracted_info_storage)

    # Make all extracted_info to DataFrame
    all_data = []
    for info in extracted_info_storage.values():
        base_info = {
            "Informal Name": info["informal_name"],
            "Reply": info["reply"]
        }
        if info["CONCEPT"]:
            for concept in info["CONCEPT"]:
                row = {**base_info, **concept}
                all_data.append(row)
        else:
            all_data.append(base_info)

    df = pd.DataFrame(all_data)
    data_extract = df  # store
    return df

# Process the extracted information and store it
def display_extracted_info(extracted_info):
    global extracted_info_storage, stored_search_terms

    search_term = extracted_info.get("search_term", "").strip()

    # Clear in every mapping as now each mapping is a new action
    extracted_info_storage.clear()
    stored_search_terms.clear()

    # Store
    if search_term:
        extracted_info_storage[search_term] = extracted_info 
        stored_search_terms.add(search_term) 

    # Generate the temp excel table for display
    output = generate_temp_excel()

    return output

# Function to save the result and action tree
def save_excel_and_append_tree():
    global mapping_result, current_action_tree, current_node

    # Add last action, which is finish mapping
    record_action("Finish Mapping", {})

    json_filename = f"{outputActionFile_name}.json"
    excel_filename = f"{outputFile_name}.xlsx"


    # Check whether result and action tree exist
    if mapping_result is None or current_action_tree is None:
        return None, None

    # Save the resul
    mapping_result.to_excel(excel_filename, index=False)

    # If json file don't exist, create a new one
    # Otherwise add to the end
    if not os.path.exists(json_filename):
        # Create a new json file
        action_history = [current_action_tree]
    else:
        # Load the current json file
        with open(json_filename, "r", encoding="utf-8") as f:
            try:
                action_history = json.load(f)
                if not isinstance(action_history, list):
                    action_history = []
            except json.JSONDecodeError:
                action_history = []

        action_history.append(current_action_tree)

    # Update record
    with open(json_filename, "w", encoding="utf-8") as f:
        json.dump(action_history, f, indent=4, ensure_ascii=False)

    # Reset
    # As user now save the mapping result, which means one turn end 

    # Clear the mapping result
    mapping_result = pd.DataFrame(columns=[
        "Informal Name", "Reply", "Concept Name", "Concept ID",
        "Domain", "Class", "Concept Code", "Vocabulary ID", "Similarity Score"
    ])

    # Clear action tree
    current_action_tree = None
    current_node = None

    # Clear table
    extracted_info_storage.clear()
    stored_search_terms.clear()

    return excel_filename, json_filename


# Send message to llama (General Search)
def get_completion(prompt, model="llama3.2", url="http://localhost:11434/api/generate", temperature=0, max_tokens=100000, timeout=10):
    headers = {
        "Content-Type": "application/json"
    }
    
    # Make sure prompt is a string
    if not isinstance(prompt, str):
        prompt = str(prompt)  

    payload = {
        "model": model,
        "prompt": prompt,
        "temperature": temperature,
        "max_tokens": max_tokens
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=timeout)
        response.raise_for_status() 

        raw_content = response.text.splitlines()
        generated_text = ""
        for line in raw_content:
            try:
                json_line = json.loads(line)
                if "response" in json_line:
                    generated_text += json_line["response"]
                if json_line.get("done", False):
                    break  
            except json.JSONDecodeError:
                print(f"Skipping invalid JSON line: {line}")
                continue

        return generated_text.strip()

    except requests.exceptions.RequestException as e:
        print(f"Error communicating with the LLaMA server: {e}")
        return None

# Function to show or hide the sidebar
def toggle_sidebar():
    
    global sidebar_visible
    # If now true switch to false 
    sidebar_visible = not sidebar_visible
    return gr.update(visible=sidebar_visible)

# The function to record the action in the action tree
def record_action(action_name, details=None):
    global current_node
    if current_node is None:
        return
    action = {
        "name": action_name,
        "details": details,
        "children": []
    }
    current_node["children"].append(action)
    current_node = action

# The function to update the sidebar
# Output is a the current action tree (In html form)
def update_sidebar_history():
    if current_action_tree is None:
        return "<i>No active mapping.</i>"
    return render_action_tree(current_action_tree)

# Generate the current tree without indentation
def render_action_tree(node, depth=0):
    arrow = "➔" if depth > 0 else "🔹"  
    html = f"<div style='font-size:14px;'>{arrow} <strong>{node['name']}</strong>: {node.get('details', '')}</div>"
    for child in node.get('children', []):
        html += render_action_tree(child, depth + 1)
    return html

# The function to apply filter
def generate_temp_excel_filter(class_filter=None, domain_filter=None, vocab_filter=None):
    global data_extract, record_action

    # No data
    # Special case (Likely to happen when reset)
    # Make sure to return 2 things
    if not extracted_info_storage:
        return None, None

    # record action
    record_action("Filter Applied", {
        "class_filter": class_filter,
        "domain_filter": domain_filter,
        "vocab_filter": vocab_filter
    })

    # all_data is those mapping suggestions suit filter 
    all_data = []
    for info in extracted_info_storage.values():
        base_info = {
            "Informal Name": info["informal_name"],
            "Reply": info["reply"]
        }

        # Only do this when something in the concept
        if info["CONCEPT"]:
            for concept in info["CONCEPT"]:
                # Filter logic
                # if (not class_filter)=True then no class filter is applied
                # Which means accept all class
                # if (concept["Class"] in class_filter)=True, which means the current class is under filter
                class_match = (not class_filter) or (concept["Class"] in class_filter)
                domain_match = (not domain_filter) or (concept["Domain"] in domain_filter)
                vocab_match = (not vocab_filter) or (concept["Vocabulary ID"] in vocab_filter)

                # Add only when fit the filter
                if class_match and domain_match and vocab_match:
                    row = {**base_info, **concept}
                    all_data.append(row)

    # Get the current tree
    current_tree = update_sidebar_history()

    # Trans all_data into  DataFrame 
    if all_data:
        df = pd.DataFrame(all_data)
        data_extract = df 
        # Retuen the mapping suggestion table and current action tree
        return df, gr.update(value=current_tree)
    else:
        # all_data isn't exist (None)
        return pd.DataFrame(), gr.update(value=current_tree)

# Generate concept graph based on concept id (Search Graph)
def generate_concept_graph(concept_id, max_depth=2, output_dir="graph", max_nodes=50):
    # The basic idea is get nodes and edges and save as a html file
    # Then open the html file in the web browser
    os.makedirs(output_dir, exist_ok=True)

    url = f"http://localhost:3000/recursive_relationships_limited/{concept_id}/{max_depth}"
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception(f"Error: {response.status_code}")

    data = response.json()

    # limit the node numver
    data['nodes'] = data['nodes'][:max_nodes]
    node_ids = set(node['id'] for node in data['nodes'])
    data['edges'] = [edge for edge in data['edges'] if edge['source_id'] in node_ids and edge['target_id'] in node_ids]

    num_nodes = len(data['nodes'])
    base_height = 500  # Height
    base_width = 800   # Weight
    scale_factor = 1.5  # Scale factor

    height = base_height + (num_nodes * scale_factor)
    width = base_width + (num_nodes * scale_factor)

    net = Network(height=f'{height}px', width=f'{width}px', directed=True, notebook=False)

    # Add node
    for node in data['nodes']:
        net.add_node(node['id'], label=node['name'], title=f"Concept ID: {node['id']}")

    # Add edge
    for edge in data['edges']:
        net.add_edge(edge['source_id'], edge['target_id'], title=edge['relationship_id'], label=edge['relationship_id'])

    # Make it looks better
    net.toggle_physics(True)
    net.show_buttons(filter_=['physics'])  

    output_path = os.path.join(output_dir, f"concept_{concept_id}_graph.html")
    net.show(output_path)

    with open(output_path, "r", encoding="utf-8") as file:
        html_content = file.read()

    print(f"Graph saved to {output_path}")
    return html_content

# The function to select the record
def select_record(evt: gr.SelectData, original_df):
    global selected_record, mapping_result
    selected_record = evt.value

    # When user select the concept id colum 
    if evt.index[1] == 3:

        if not selected_record:
            return gr.update(visible=True)

        try:
            # Generate and save the html file
            generate_concept_graph(selected_record)

            # The path of html file
            html_path = os.path.abspath(f"graph/concept_{selected_record}_graph.html")

            # Open the html file with a browser
            webbrowser.open(f"file://{html_path}")

            message = f"Show the OMOP relationship graph of {selected_record}"

            # Record action
            record_action(f"Check OMOP relationship graph of {selected_record}", {})

            # Update the tree
            current_tree = update_sidebar_history()
            # Display a message to tell the user what he done
            return gr.update(value=message), gr.update(value=current_tree)

        except Exception as e:
            return gr.update(visible=True), gr.update(value=current_tree)

    clicked_row, clicked_col = evt.index
    # When user click the concept name ---> save this mapping suggestion to the result table
    if clicked_col == 2:
        # Get every thing in that line
        selected_row = original_df.iloc[clicked_row]
        # Add to mapping_result
        mapping_result = pd.concat([mapping_result, selected_row.to_frame().T], ignore_index=True)

        message = f"You add {selected_record} into the mapping result!"
        
        record_action(f"Map to {selected_record}", {})
        current_tree = update_sidebar_history()

        current_tree = update_sidebar_history()
        return gr.update(value=message), gr.update(value=current_tree)

# Logic for Button Availability 
def toggle_mapping_button(x):
    # If non-empty: can interactive
    return gr.update(interactive=True) if x.strip() else gr.update(interactive=False)

# The function to get LLM response (For general research)
def get_llm_response(input):

    # Record the action of general search
    record_action("Use LLM Do General Search ", {
    "Question": input
    })
    current_tree = update_sidebar_history()
    result = (prompt | llm).invoke(input)
    return result, gr.update(value=current_tree)


def load_other_action_tree(file):
    if file is None:
        return gr.update(value="<i>No file selected.</i>")

    with open(file.name, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            return gr.update(value="<i>Invalid JSON file.</i>")

    if isinstance(data, list) and len(data) > 0:
        other_tree = data[-1]
    elif isinstance(data, dict):
        other_tree = data
    else:
        return gr.update(value="<i>Invalid action tree format.</i>")

    return gr.update(value=render_action_tree(other_tree))

# --------------------------------------------------------------
# Front-end
# Construct the gradio UI
with gr.Blocks(css="""
/* Sidebar */
#sidebar {
    transition: transform 0.3s ease;
    position: fixed;
    top: 0;
    left: 0;
    width: 250px;
    background-color: #ffffff;
    height: 100vh;
    padding: 20px;
    box-shadow: 4px 0 10px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    transform: translateX(-100%);
}

/* When sidebar is visible, move it back*/
#sidebar.visible {
    transform: translateX(0);
}

/* The button to open sidebar */
#open_button {
    position: fixed;
    top: 20px;
    left: 20px;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background-color: #007bff;
    color: white;
    font-size: 24px;
    border: none;
    cursor: pointer;
    box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
    transition: background-color 0.3s ease, transform 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

#open_button:hover {
    background-color: #0056b3;
    transform: scale(1.1);
}

/* The button to close sidebar */
#close_button {
    margin-top: auto;
    width: 100%;
    padding: 10px;
    background-color: #ff4d4d;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 1s ease;
}

#close_button:hover {
    background-color: #cc0000;
}

#right_column {
    display: flex;
    flex-direction: column;
    height: 100%;
}

#llm_response_output {
    flex-grow: 1;
    overflow-y: auto;
    min-height: 200px;
}

#action_tree_container {
    height: 300px;         
    overflow-y: auto;      
    border: 1px solid #ddd;
    padding: 5px;
    border-radius: 5px;
}

#action_tree_container, #loaded_action_tree_container {
    height: 300px;
    overflow-y: auto;
    border: 1px solid #ddd;
    padding: 5px;
    border-radius: 5px;
    margin-bottom: 10px;
}
""") as demo:

    gr.Markdown("## **Mapping Suggestion Interface**")

    # The sidebar to show the action history
    with gr.Column(scale=1, elem_id="sidebar", visible=False, elem_classes="visible") as sidebar:        
        
        with gr.Column(elem_id="action_tree_container"):
            gr.Markdown("### Action History")
            sidebar_history_display = gr.HTML(label="History Tree", value="", visible=True)

        
        with gr.Column(elem_id="loaded_action_tree_container"):
            gr.Markdown("#### Loaded Action Tree (For Comparison)")
            loaded_action_tree_display = gr.HTML(label="Loaded History Tree", value="", visible=True)
        
        
        with gr.Column():
            gr.Markdown("#### Load An Action Tree")
            load_file = gr.File(label="Upload Action Tree File", file_types=[".json", ".txt"])
            load_button = gr.Button("Load Action Tree")
            load_button.click(
                fn=load_other_action_tree,
                inputs=[load_file],
                outputs=[loaded_action_tree_display]
            )

            close_button = gr.Button("Close Sidebar", elem_id="close_button")
            close_button.click(fn=toggle_sidebar, outputs=[sidebar])
    
    # The button to open the side bar
    open_button = gr.Button("☰", elem_id="open_button")

    open_button.click(
        fn=toggle_sidebar,
        outputs=[sidebar]
    )

    

    # Upper Section: Search Input + Filters
    with gr.Row(equal_height=True):
        with gr.Column(scale=1):
            # Search Input and Apply Filters
            gr.Markdown("### **Search Input**")
            text_input = gr.Textbox(label="Enter search term", placeholder="Type your query here...")
            mapping_button = gr.Button("Find Mapping", visible=True, interactive=False)
            
            gr.Markdown("### **Filters**")
            filter_class = gr.Dropdown(label="Filter by Concept Class", choices=[], multiselect=True)
            filter_domain = gr.Dropdown(label="Filter by Domain", choices=[], multiselect=True)
            filter_vocab = gr.Dropdown(label="Filter by Vocabulary", choices=[], multiselect=True)
            
            #output = gr.Textbox()
        with gr.Column(scale=1, elem_id="right_column"):
            # Lower Section: General LLM Search
            gr.Markdown("### **General Search using LLM**")

            # Upper half
            with gr.Column():
                llm_query = gr.Textbox(label="Ask anything", placeholder="E.g., What is paracetamol called in the USA?")
                llm_search_button = gr.Button("Ask", visible=True, interactive=False)
                llm_query.change(toggle_mapping_button, inputs=[llm_query], outputs=[llm_search_button])
        
            # Get the response of LLM
            llm_response_output = gr.Textbox(label="LLM Response", interactive=False, lines=15, elem_id="llm_response_output")

            llm_search_button.click(fn=get_llm_response, inputs=[llm_query], outputs=[llm_response_output, sidebar_history_display]) 

    # Middle Section: Mapping Results
    gr.Markdown("### **Results Table**")
    # temp_table_output show the mapping suggestion from lettuce
    temp_table_output = gr.DataFrame(label="Mapped Results", visible=False)

    # This is the message to show what user click
    temp_table_output_click = gr.Textbox(label="Movement", value="Nothing Change", interactive=False)
    
    # The button to save the result
    save_button = gr.Button("Save as Excel", visible=False)
    
    download_excel = gr.File(label="Download Mapping Excel", visible=False)
    download_history = gr.File(label="Download History JSON", visible=False)

    # Avoid empty input
    text_input.change(toggle_mapping_button, inputs=[text_input], outputs=[mapping_button])
    
    # Get suggestion and store
    def process_and_store(x):
        global current_action_tree, current_node, mapping_result, outputFile_name, outputActionFile_name

        if not x.strip():
            return

        
        outputFile_name = f"mapping_results_{x}"
        outputActionFile_name = f"action_history_{x}"

        # Mapping result initialization
        mapping_result = pd.DataFrame(columns=[
        "Informal Name", "Reply", "Concept Name", "Concept ID",
        "Domain", "Class", "Concept Code", "Vocabulary ID", "Similarity Score"
        ])

        # Construct tree
        current_action_tree = {
            "name": "Mapping Search",
            "details": {"search_term": x},
            "children": []
        }
        # Record current node
        current_node = current_action_tree

        # Get mapping suggestions
        extracted_info = query_pipeline([x])
        temp_table = display_extracted_info(extracted_info)

        # extract all class, domain, vocabulary
        classes = []
        domains = []
        vocabularies = []
        for item in extracted_info_storage.values():
            for concept in item["CONCEPT"]:
                classes.append(concept["Class"])
                domains.append(concept["Domain"])
                vocabularies.append(concept["Vocabulary ID"])

        # Avoid duplication
        classes = list(set(classes))
        domains = list(set(domains))
        vocabularies = list(set(vocabularies))

        current_tree = update_sidebar_history()

        #print(classes)
        #print(domains)
        #print(vocabularies)
        return (
        temp_table,
        gr.update(visible=True),
        gr.update(visible=True), 
        gr.update(choices = classes),
        gr.update(choices = domains),
        gr.update(choices = vocabularies),
        gr.update(value = []),
        gr.update(value = []),
        gr.update(value = []),
        # For update sidebar
        gr.update(value=current_tree)

        )

        #return temp_table, gr.update(visible=True), gr.update(visible=True), gr.Dropdown.update(choices=extracted_info_storage["class"]), gr.Dropdown.update(choices=extracted_info_storage["domain"]), gr.Dropdown.update(choices=extracted_info_storage["vocabulary"])
    
    # Mapping
    mapping_button.click(
        fn=process_and_store, 
        inputs=[text_input], 
        outputs=[temp_table_output, temp_table_output, save_button, filter_class, filter_domain, filter_vocab, filter_class, filter_domain, filter_vocab, sidebar_history_display]
    )

    # Filter 
    filter_class.change(generate_temp_excel_filter, inputs=[filter_class, filter_domain, filter_vocab], outputs=[temp_table_output, sidebar_history_display])
    filter_domain.change(generate_temp_excel_filter, inputs=[filter_class, filter_domain, filter_vocab], outputs=[temp_table_output, sidebar_history_display])
    filter_vocab.change(generate_temp_excel_filter, inputs=[filter_class, filter_domain, filter_vocab], outputs=[temp_table_output, sidebar_history_display])



    #graph_display = gr.HTML(label="Concept Graph", visible=True)

    # When user select ID or name
    # ID for check graph
    # Table for add to the result
    temp_table_output.select(select_record, inputs=[temp_table_output], outputs=[temp_table_output_click, sidebar_history_display])


    # Save result and action
    def save_and_return_files():
        excel_file, history_file = save_excel_and_append_tree()
        current_tree = update_sidebar_history()
        
        searchInput = ""
        filter1 = []
        filter2 = []
        filter3 = []
        empty_df = pd.DataFrame()
    
        generalInput = ""
        generalOutput = ""
        
        movement = "Nothing Change"

        load_actionFile = None
        load_Html = ""

        # Clear action tree
        current_action_tree = None
        current_node = None
        return (
            excel_file, 
            history_file, 
            gr.update(value=current_tree), 
            gr.update(value=searchInput), 
            gr.update(value=filter1),
            gr.update(value=filter2),
            gr.update(value=filter3),
            gr.update(value=empty_df),
            gr.update(value=generalInput),
            gr.update(value=generalOutput),
            gr.update(value=movement),
            gr.update(value=load_actionFile),
            gr.update(value=load_Html)
        )
    save_button.click(fn=save_and_return_files, inputs=[], outputs=[download_excel, download_history,sidebar_history_display, text_input, filter_class, filter_domain, filter_vocab, temp_table_output, llm_query, llm_response_output, temp_table_output_click, load_file, loaded_action_tree_display])




demo.launch(share=False)











